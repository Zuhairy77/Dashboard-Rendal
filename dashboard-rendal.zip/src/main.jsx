import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import DashboardRendal from './DashboardRendal'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <DashboardRendal />
  </React.StrictMode>
)
