import React from 'react'

const data = [
  { kegiatan: "Pondasi", mulai: "2025-06-01", selesai: "2025-06-07", progres: 100, pic: "Budi", status: "Selesai" },
  { kegiatan: "Struktur", mulai: "2025-06-08", selesai: "2025-06-15", progres: 60, pic: "Sari", status: "On Track" },
  { kegiatan: "Finishing", mulai: "2025-06-16", selesai: "2025-06-22", progres: 10, pic: "Dian", status: "Delay" }
];

export default function DashboardRendal() {
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold">Dashboard Rencana dan Pengendalian (Rendal)</h1>
      <div className="overflow-x-auto border rounded-lg">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-2 text-left">Nama Kegiatan</th>
              <th className="p-2 text-left">Mulai</th>
              <th className="p-2 text-left">Selesai</th>
              <th className="p-2 text-left">Progres</th>
              <th className="p-2 text-left">PIC</th>
              <th className="p-2 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, index) => (
              <tr key={index} className="border-t">
                <td className="p-2">{item.kegiatan}</td>
                <td className="p-2">{item.mulai}</td>
                <td className="p-2">{item.selesai}</td>
                <td className="p-2">{item.progres}%</td>
                <td className="p-2">{item.pic}</td>
                <td className="p-2">{item.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
